import { AssessmentAllocationController } from "./assessment-allocation.controller";
import { AssessmentController } from "./assessment.controller";

export const Controllers = [AssessmentAllocationController, AssessmentController];
