import { AssessmentAllocationService } from "./assessment-allocation.service";
import { AssessmentService } from "./assessment.service";

export const Services = [AssessmentAllocationService, AssessmentService];
