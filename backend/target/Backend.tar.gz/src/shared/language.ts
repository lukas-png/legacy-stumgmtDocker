export enum Language {
	EN = "EN",
	DE = "DE"
}
