export class LinkDto {
	url: string;
	name: string;
}
