export class PasswordDto {
	password: string;
}
